<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfd8abae7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\146\x6f\162\x65\x5f\151\x6e\x76\157\x69\143\145\137\143\157\156\x74\x65\156\x74", [$this, "\141\157\147\x71\141\167\x65\x61\147\x71\x67\x63\x69\x77\141\x6f"])->qcsmikeggeemccuu("\x61\146\164\145\162\x5f\x69\156\x76\x6f\x69\143\x65\x5f\143\x6f\156\x74\x65\x6e\x74", [$this, "\x67\161\167\x73\x6d\167\x69\x77\141\x73\x79\155\153\143\163\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\160\155\x6c\x5f\x6c\x61\156\147\165\x61\x67\x65", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
