<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b78fa11aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice\Traits; use Pmpr\Module\WoocommerceInvoice\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
