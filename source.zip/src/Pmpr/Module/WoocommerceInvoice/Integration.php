<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5eb71364             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\x65\146\x6f\x72\x65\x5f\151\x6e\x76\x6f\x69\x63\145\137\143\157\156\x74\x65\x6e\x74", [$this, "\x61\x6f\x67\x71\141\x77\x65\141\x67\x71\x67\x63\x69\x77\x61\157"])->qcsmikeggeemccuu("\141\x66\164\x65\x72\x5f\151\x6e\166\157\151\143\x65\x5f\x63\157\x6e\164\x65\156\x74", [$this, "\x67\x71\x77\163\x6d\167\x69\167\x61\163\171\x6d\153\x63\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\160\x6d\x6c\x5f\154\141\x6e\147\165\x61\147\x65", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
