<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b78fa11aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\146\x6f\x72\145\137\x69\x6e\x76\157\x69\x63\145\137\x63\x6f\156\164\x65\156\164", [$this, "\141\157\147\161\x61\167\145\141\147\x71\147\x63\151\x77\141\157"])->qcsmikeggeemccuu("\x61\x66\x74\145\162\137\x69\156\166\x6f\x69\x63\145\x5f\143\x6f\156\164\x65\x6e\164", [$this, "\147\161\x77\x73\x6d\167\x69\x77\x61\x73\x79\x6d\153\x63\x73\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\160\x6d\x6c\137\x6c\141\156\x67\165\x61\147\145", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
