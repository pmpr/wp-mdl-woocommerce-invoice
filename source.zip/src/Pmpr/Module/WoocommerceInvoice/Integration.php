<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af1c4e93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\145\x66\x6f\162\145\137\151\x6e\166\157\151\x63\145\137\x63\157\x6e\x74\x65\156\164", [$this, "\x61\x6f\147\161\x61\x77\x65\x61\147\161\x67\x63\151\167\141\157"])->qcsmikeggeemccuu("\141\x66\x74\145\162\x5f\x69\x6e\166\157\x69\x63\x65\x5f\143\x6f\156\164\145\x6e\164", [$this, "\147\x71\167\163\155\167\151\167\x61\x73\x79\155\x6b\x63\163\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\160\155\x6c\137\154\x61\x6e\147\x75\x61\147\145", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
