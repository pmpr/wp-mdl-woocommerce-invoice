<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             684453ffd43c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice\Traits; use Pmpr\Module\WoocommerceInvoice\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
