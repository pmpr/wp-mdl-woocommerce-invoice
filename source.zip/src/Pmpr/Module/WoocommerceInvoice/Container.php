<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfd8abae7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
